<?php

use Illuminate\Support\Facades\Route;
//import java.io.* ;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
}); //hanya cocok untuk simple redirect

Route::get('halo', function () {
	return "<marquee>Halo, Selamat datang di tutorial laravel www.malasngoding.com</marquee>";
});

Route::get('blog', function () {
	return view('blog');
});

Route::get('dosen', '\App\Http\Controllers\DosenController@index');

Route::get('/pegawai/nama/{nama}', '\App\Http\Controllers\PegawaiController@index');

Route::get('/formulir', '\App\Http\Controllers\PegawaiController@formulir');
Route::post('/formulir/proses', '\App\Http\Controllers\PegawaiController@proses');

Route::get('/blog', '\App\Http\Controllers\BlogController@home');
Route::get('/blog/tentang', '\App\Http\Controllers\BlogController@tentang');
Route::get('/blog/kontak', '\App\Http\Controllers\BlogController@kontak');

Route::get('/pegawai','\App\Http\Controllers\PegawaiDBController@index');

Route::get('/pegawai/tambah','\App\Http\Controllers\PegawaiDBController@tambah');

Route::post('/pegawai/store','\App\Http\Controllers\PegawaiDBController@store');
Route::get('/pegawai/edit/{id}', '\App\Http\Controllers\PegawaiDBController@edit');
Route::post('/pegawai/update', '\App\Http\Controllers\PegawaiDBController@update');
Route::get('/pegawai/hapus/{id}', '\App\Http\Controllers\PegawaiDBController@hapus');
Route::get('/pegawai/cari','\App\Http\Controllers\PegawaiDBController@cari');
Route::get('/pegawai/view/{id}', '\App\Http\Controllers\PegawaiDBController@view');

Route::get('/karyawan','\App\Http\Controllers\KaryawanController@index');

Route::get('/karyawan/edit/{id}', '\App\Http\Controllers\KaryawanController@edit');
Route::post('/karyawan/update', '\App\Http\Controllers\KaryawanController@update');

Route::get('/karyawan/view/{id}', '\App\Http\Controllers\KaryawanController@view');

Route::get('/shoppingchart','\App\Http\Controllers\ShoppingChartController@index');
Route::get('/shoppingchart/beli','\App\Http\Controllers\ShoppingChartController@beli');
Route::post('/shoppingchart/store','\App\Http\Controllers\ShoppingChartController@store');
Route::get('/shoppingchart/edit/{id}', '\App\Http\Controllers\ShoppingChartController@edit');
Route::post('/shoppingchart/update', '\App\Http\Controllers\ShoppingChartController@update');
Route::get('/shoppingchart/batal/{id}', '\App\Http\Controllers\ShoppingChartController@batal');

Route::get('/shoppingchart/view/{id}', '\App\Http\Controllers\ShoppingChartController@view');

Route::get('/profil','\App\Http\Controllers\ProfilController@index');
Route::get('/profil/buat', '\App\Http\Controllers\ProfilController@buat');
Route::post('/profil/store','\App\Http\Controllers\ProfilController@store');
Route::get('/profilpelanggan','\App\Http\Controllers\ProfilController@indexedit');
Route::get('/profil/edit/{id}', '\App\Http\Controllers\ProfilController@edit');
Route::post('/profil/update', '\App\Http\Controllers\ProfilController@update');