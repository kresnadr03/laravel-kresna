<!DOCTYPE html>
<html>
<head>
	<title>Shopping Chart</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>

<!-- Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
    <div class="jumbotron">
        <h2 style="text-align: center">5026211114_Kresna Dwipayana Ramadhani</h2>
        <h3 style="text-align: center">Shopping Chart</h3>



    <?php echo $__env->yieldContent('atas'); ?>

	<br/>
	<br/>


<?php echo $__env->yieldContent('isinya'); ?>
<?php echo $__env->yieldContent(''); ?>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PWEB 2022\resources\views/kresna.blade.php ENDPATH**/ ?>