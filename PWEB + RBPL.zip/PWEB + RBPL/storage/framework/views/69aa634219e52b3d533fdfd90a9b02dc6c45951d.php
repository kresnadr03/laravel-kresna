<?php $__env->startSection('atas'); ?>
<a href="/shoppingchart/beli" type="button" class="btn btn-primary"> Beli</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isinya'); ?>


    <table class="table table-striped">
    <thead>
        <tr>
            <th>Kode Barang</th>
            <th>Jumlah
                Pembelian
            </th>
            <th>Harga per
                Item
            </th>
            <th>Total
                Jumlah x Harga
            </th>
            <th>Opsi</th>
        </tr>
    </thead>
        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($p->id); ?></td>
                <td><?php echo e($p->KodeBarang); ?></td>
                <td><?php echo e($p->Jumlah); ?></td>
                <td><?php echo e("Rp " . number_format($p->Harga,0,',','.')); ?></td>
                <td><?php echo e("Rp " . number_format($p->Harga * $p->Jumlah,0,',','.')); ?></td>
                <td>

                    <a href="/shoppingchart/batal/<?php echo e($p->id); ?>" class="btn btn-primary" role="button">Batal</a>

                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('kresna', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PWEB 2022\resources\views/indexshoppingchart.blade.php ENDPATH**/ ?>