<?php $__env->startSection('atas'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('isinya'); ?>
    <table class="table table-striped">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Jabatan</th>
            <th>Umur</th>
            <th>Alamat</th>
            <th>Opsi</th>
        </tr>
    </thead>
        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($p->pegawai_nama); ?></td>
                <td><?php echo e($p->pegawai_jabatan); ?></td>
                <td><?php echo e($p->pegawai_umur); ?></td>
                <td><?php echo e($p->pegawai_alamat); ?></td>
                <td>
                    <a href="/pegawai/edit/<?php echo e($p->pegawai_id); ?>" class="btn btn-info" role="button">Edit</a>
                    <a href="/pegawai/hapus/<?php echo e($p->pegawai_id); ?>" class="btn btn-info" role="button">Hapus</a>
                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('yudhis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pwebklsa\resources\views/index.blade.php ENDPATH**/ ?>