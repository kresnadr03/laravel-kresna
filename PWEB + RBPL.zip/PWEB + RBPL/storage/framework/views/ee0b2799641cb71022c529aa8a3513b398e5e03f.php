<!DOCTYPE html>
<html>
<head>
    

    <?php $__env->startSection('atas'); ?>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('isinya'); ?>

	<a href="/shoppingchart" type="button" type="button" class="btn btn-primary"> Kembali</a>

	<br/>
	<br/>

	<form action="/shoppingchart/store" method="post">
		<?php echo e(csrf_field()); ?>




        <div class="form-group row">
            <label for="kodebarang" class="col-sm-2 col-form-label">Kode Barang</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="kodebarang" required="required" id="kodebarang"
                    placeholder="Kode Barang">
            </div>
        </div>

        <div class="form-group row">
            <label for="jumlah" class="col-sm-2 col-form-label">Jumlah</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name="jumlah" required="required" id="jumlah"
                    placeholder="Jumlah">
            </div>
        </div>

        <div class="form-group row">
            <label for="harga" class="col-sm-2 col-form-label">Harga</label>
            <div class="col-sm-10">
                <input type="harga" class="form-control" name="harga" required="required" id="harga"
                    placeholder="Harga">
            </div>
        </div>

        
		<input type="submit" value="Simpan Data">
	</form>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('kresna', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwklsd\resources\views/beli.blade.php ENDPATH**/ ?>