<?php $__env->startSection('atas'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('isinya'); ?>
<h3>Lihat Data Pegawai</h3>
	<a href="/pegawai" type="button" class="btn btn-primary"> Kembali</a>

	<br/>
	<br/>

	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="/pegawai/update" method="post">

		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="id" value="<?php echo e($p->pegawai_id); ?>"> <br/>

        <div class="form-group row">
            <label for="nama" class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="nama" required="required" id="nama"
                    placeholder="Nama" value="<?php echo e($p->pegawai_nama); ?>">
            </div>
        </div>

        <div class="form-group row">
            <label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="jabatan" required="required" id="jabatan"
                    placeholder="Jabatan" value="<?php echo e($p->pegawai_jabatan); ?>">
            </div>
        </div>

        <div class="form-group row">
            <label for="umur" class="col-sm-2 col-form-label">Umur</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name="umur" required="required" id="umur"
                    placeholder="Umur" value="<?php echo e($p->pegawai_umur); ?>">
            </div>
        </div>

        <div class="form-group row">
            <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
            <div class="col-sm-10">
                <textarea name="alamat" required="required" id="alamat" placeholder="Alamat"><?php echo e($p->pegawai_alamat); ?></textarea>
            </div>
        </div>

        
		<input type="submit" value="Simpan Data">
	</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('kresna', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwklsd\resources\views/edit.blade.php ENDPATH**/ ?>