<!DOCTYPE html>
<html>
<head>
    

    <?php $__env->startSection('atas'); ?>

    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('isinya'); ?>

	<a href="/pegawai" type="button" type="button" class="btn btn-primary"> Kembali</a>

	<br/>
	<br/>

	<form action="/pegawai/store" method="post">
		<?php echo e(csrf_field()); ?>


        <div class="form-group row">
            <label for="nama" class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="nama" required="required" id="nama"
                    placeholder="Nama">
            </div>
        </div>

        <div class="form-group row">
            <label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="jabatan" required="required" id="jabatan"
                    placeholder="Jabatan">
            </div>
        </div>

        <div class="form-group row">
            <label for="umur" class="col-sm-2 col-form-label">Umur</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name="umur" required="required" id="umur"
                    placeholder="Umur">
            </div>
        </div>

        <div class="form-group row">
            <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
            <div class="col-sm-10">
                <textarea name="alamat" required="required" id="alamat" placeholder="Alamat"></textarea>
            </div>
        </div>

        
		<input type="submit" value="Simpan Data">
	</form>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('kresna', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PWEB 2022\resources\views/tambah.blade.php ENDPATH**/ ?>