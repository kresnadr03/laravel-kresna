<?php $__env->startSection('atas'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('isinya'); ?>
	<a href="/pegawai" type="button" class="btn btn-primary"> Kembali</a>

	<br/>
	<br/>

	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="form-group row">
            <label for="nama" class="col-sm-2 col-form-label">Pegawai ID</label>
            <div class="col-sm-10">
                <label class="col-form-label"><?php echo e($p->pegawai_id); ?>"</label>
            </div>
        </div>
        <div class="form-group row">
            <label for="nama" class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-10">
                <label class="col-form-label"><?php echo e($p->pegawai_nama); ?>"</label>
            </div>
        </div>

        <div class="form-group row">
            <label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-10">
                <label class="col-form-label"><?php echo e($p->pegawai_jabatan); ?>"</label>
            </div>
        </div>

        <div class="form-group row">
            <label for="umur" class="col-sm-2 col-form-label">Umur</label>
            <div class="col-sm-10">
                <label class="col-form-label"><?php echo e($p->pegawai_umur); ?>"</label>
            </div>
        </div>

        <div class="form-group row">
            <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
            <div class="col-sm-10">
                <label class="col-form-label"><?php echo e($p->pegawai_alamat); ?></label>
            </div>
        </div>

        


	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('kresna', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwklsd\resources\views/view.blade.php ENDPATH**/ ?>