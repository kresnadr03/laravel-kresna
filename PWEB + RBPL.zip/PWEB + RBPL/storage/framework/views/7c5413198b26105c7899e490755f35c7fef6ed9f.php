<?php $__env->startSection('atas'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('isinya'); ?>


    <table class="table table-striped">
    <thead>
        <tr>
            <th>NIP</th>
            <th>Nama</th>
            <th>Pangkat</th>
            <th>Gaji</th>
            <th>Opsi</th>
        </tr>
    </thead>
        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($p->NIP); ?></td>
                <td><?php echo e($p->Nama); ?></td>
                <td><?php echo e($p->Pangkat); ?></td>
                <td><?php echo e($p->Gaji); ?></td>
                <td>
                    <a href="/pegawai/view/<?php echo e($p->NIP); ?>" class="btn btn-primary" role="button">View</a>
                    <a href="/pegawai/edit/<?php echo e($p->NIP); ?>" class="btn btn-primary" role="button">Edit</a>

                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('kresna', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwklsd\resources\views/indexkaryawan.blade.php ENDPATH**/ ?>