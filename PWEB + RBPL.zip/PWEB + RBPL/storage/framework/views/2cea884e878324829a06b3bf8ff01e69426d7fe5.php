<!DOCTYPE html>
<html>

<head>
    <title>Tutorial Membuat CRUD Pada Laravel - www.malasngoding.com</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

    <h2><a>5026211106_Yudhistira Azhar Haryono Putra</a></h2>
    <h3>Edit Pegawai</h3>

    <a href="/pegawai"> Kembali</a>

    <br />
    <br />

    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/pegawai/update" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e($p->pegawai_id); ?>"> <br />

            <div class="form-group row">
                <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="nama" required="required" id="nama"
                        placeholder="Nama" value="<?php echo e($p->pegawai_nama); ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="jabatan" required="required" id="jabatan"
                        placeholder="Jabatan" value="<?php echo e($p->pegawai_jabatan); ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="umur" class="col-sm-2 col-form-label">Umur</label>
                <div class="col-sm-10">
                    <input type="number" class="form-control" name="umur" required="required" id="umur"
                        placeholder="Umur" value="<?php echo e($p->pegawai_umur); ?>">
                </div>
            </div>

            <div class="form-group row">
                <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-10">
                    <textarea name="alamat" required="required" id="alamat" placeholder="Alamat"><?php echo e($p->pegawai_alamat); ?></textarea>
                </div>
            </div>

            
            <input type="submit" value="Simpan Data">
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</body>

</html>
<?php /**PATH C:\xampp\htdocs\pwebklsa\resources\views/edit.blade.php ENDPATH**/ ?>