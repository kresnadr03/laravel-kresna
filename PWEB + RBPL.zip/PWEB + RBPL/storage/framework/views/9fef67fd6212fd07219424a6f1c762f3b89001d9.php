<?php $__env->startSection('atas'); ?>
<a href="/pegawai/tambah" type="button" class="btn btn-primary"> + Tambah Pegawai Baru</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isinya'); ?>
<p>Cari Data Pegawai :</p>
	<form action="/pegawai/cari" method="GET">
		<input type="text" class="form-control" name="cari" placeholder="Cari Pegawai .." value="<?php echo e(old('cari')); ?>">
		<input class="btn btn-primary btn-sm" type="submit" value="CARI">
	</form>


    <table class="table table-striped">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Jabatan</th>
            <th>Umur</th>
            <th>Alamat</th>
            <th>Opsi</th>
        </tr>
    </thead>
        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>
                <td><?php echo e($p->pegawai_nama); ?></td>
                <td><?php echo e($p->pegawai_jabatan); ?></td>
                <td><?php echo e($p->pegawai_umur); ?></td>
                <td><?php echo e($p->pegawai_alamat); ?></td>
                <td>
                    <a href="/pegawai/view/<?php echo e($p->pegawai_id); ?>" class="btn btn-primary" role="button">View</a>
                    <a href="/pegawai/edit/<?php echo e($p->pegawai_id); ?>" class="btn btn-primary" role="button">Edit</a>
                    <a href="/pegawai/hapus/<?php echo e($p->pegawai_id); ?>" class="btn btn-primary" role="button">Hapus</a>

                </td>
            </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($pegawai->links()); ?>

<?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('kresna', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PWEB 2022\resources\views/index.blade.php ENDPATH**/ ?>