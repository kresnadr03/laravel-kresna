<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KaryawanController extends Controller
{
    public function index() //nama metodd bebas
    {
    	// mengambil data dari table pegawai
    	$pegawai = DB::table('karyawan1')->get();//return     array of object
// dipilih salah satu

    	// mengirim data pegawai ke view index
    	return view('indexkaryawan',['pegawai' => $pegawai]);
    }
    public function edit($id) {
        // mengambil data pegawai berdasarkan id yang dipilih
        $pegawai = DB::table('karyawan1')->where('NIP',$id)->get();
        // passing data pegawai yang didapat ke view edit.blade.php
        return view('edit',['pegawai' => $pegawai]);
    }
    public function update(Request $request) {
        // update data pegawai
        DB::table('karyawan1')->where('NIP',$request->id)->update([
            'Nama' => $request->Nama,
            'Pangkat' => $request->Pangkat,
            'Gaji' => $request->Gaji,

        ]);
        // alihkan halaman ke halaman pegawai
        return redirect('/pegawai');
    }
    public function view($id) {
        // mengambil data pegawai berdasarkan id yang dipilih
        $pegawai = DB::table('karyawan1')->where('NIP',$id)->get();
        // passing data pegawai yang didapat ke view edit.blade.php
        return view('view',['pegawai' => $pegawai]);
    }
}
