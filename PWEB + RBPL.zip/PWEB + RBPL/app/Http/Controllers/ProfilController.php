<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProfilController extends Controller
{
    /**
     * Show the update profile page.
     *
     * @param  Request $request
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index() //nama metodd bebas
    {
    	// mengambil data dari table pegawai
    	$pegawai = DB::table('pelanggan')->get();//return     array of object
// dipilih salah satu
// $pegawai = DB::table('pegawai')->paginate(5);
    	// mengirim data pegawai ke view index
    	return view('indexprofil',['pegawai' => $pegawai]);
    }

    public function indexedit() //nama metodd bebas
    {
    	// mengambil data dari table pegawai
    	$pegawai = DB::table('pelanggan')->get();//return     array of object
// dipilih salah satu
// $pegawai = DB::table('pegawai')->paginate(5);
    	// mengirim data pegawai ke view index
    	return view('indexeditprofil',['pegawai' => $pegawai]);
    }

     public function buat()
    {
        $pegawai = DB::table('pelanggan')->get();//return     array of object
// dipilih salah satu
// $pegawai = DB::table('pegawai')->paginate(5);
    	// mengirim data pegawai ke view index
    	return view('buatprofil');
        // memanggil view tambah

    }

    public function store(Request $request)
    {
        // insert data ke table pegawai
        DB::table('pelanggan')->insert([
            'pelangganID' => $request->id,
            'nama_pelanggan' => $request->nama,
            'lokasi_pelanggan' => $request->lokasi,
            'email_pelanggan' => $request->email,
            'nomorHP_pelanggan' => $request->nomorhp
        ]);
        // alihkan halaman ke halaman pegawai
        return redirect('/profilpelanggan');

    }

     public function edit($id) {
        // mengambil data pegawai berdasarkan id yang dipilih
        $pegawai = DB::table('pelanggan')->where('pelangganID',$id)->get();
        // passing data pegawai yang didapat ke view edit.blade.php
        return view('editprofil',['pegawai' => $pegawai]);
    }

    public function update(Request $request) {
        // update data pegawai
        DB::table('pelanggan')->where('pelangganID',$request->id)->update([
            'pelangganID' => $request->id,
            'nama_pelanggan' => $request->nama,
            'lokasi_pelanggan' => $request->lokasi,
            'email_pelanggan' => $request->email,
            'nomorHP_pelanggan' => $request->nomorhp
        ]);
        // alihkan halaman ke halaman pegawai
        return redirect('/profilpelanggan');
    }
}