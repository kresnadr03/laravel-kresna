<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ShoppingChartController extends Controller
{
    public function index() //nama metodd bebas
    {
    	// mengambil data dari table pegawai
    	$pegawai = DB::table('shoppingchart')->get();//return     array of object
// dipilih salah satu
// $pegawai = DB::table('pegawai')->paginate(5);
    	// mengirim data pegawai ke view index
    	return view('indexshoppingchart',['pegawai' => $pegawai]);
    }

    // method untuk menampilkan view form tambah pegawai
    public function beli()
    {
        $pegawai = DB::table('shoppingchart')->get();//return     array of object
// dipilih salah satu
// $pegawai = DB::table('pegawai')->paginate(5);
    	// mengirim data pegawai ke view index
    	return view('beli');
        // memanggil view tambah

    }
    public function store(Request $request)
    {
        // insert data ke table pegawai
        DB::table('shoppingchart')->insert([
            'id' => $request->id,
            'kodebarang' => $request->kodebarang,
            'jumlah' => $request->jumlah,
            'harga' => $request->harga
        ]);
        // alihkan halaman ke halaman pegawai
        return redirect('/shoppingchart');

    }
    public function edit($id) {
        // mengambil data pegawai berdasarkan id yang dipilih
        $pegawai = DB::table('shoppingchart')->where('id',$id)->get();
        // passing data pegawai yang didapat ke view edit.blade.php
        return view('edit',['pegawai' => $pegawai]);
    }

    public function update(Request $request) {
        // update data pegawai
        DB::table('shoppingchart')->where('id',$request->id)->update([
            'id' => $request->id,
            'KodeBarang' => $request->KodeBarang,
            'Jumlah' => $request->Jumlah,
            'Harga' => $request->Harga
        ]);
        // alihkan halaman ke halaman pegawai
        return redirect('/pegawai');
    }

    public function batal($id){
        //menghapus data pegawai berdasarkan id
        DB::table('shoppingchart')->where('id',$id)->delete();
        //alihkan halaman ke halaman pegawai
        return redirect('/shoppingchart');
    }


    public function view($id) {
        // mengambil data pegawai berdasarkan id yang dipilih
        $pegawai = DB::table('shoppingchart')->where('id',$id)->get();
        // passing data pegawai yang didapat ke view edit.blade.php
        return view('view',['pegawai' => $pegawai]);
    }
}
