<!DOCTYPE html>
<html>
<head>
    @extends('kresna')

    @section('atas')

    @endsection

    @section('isinya')

	<a href="/pegawai" type="button" type="button" class="btn btn-primary"> Kembali</a>

	<br/>
	<br/>

	<form action="/pegawai/store" method="post">
		{{ csrf_field() }}

        <div class="form-group row">
            <label for="nama" class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="nama" required="required" id="nama"
                    placeholder="Nama">
            </div>
        </div>

        <div class="form-group row">
            <label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" name="jabatan" required="required" id="jabatan"
                    placeholder="Jabatan">
            </div>
        </div>

        <div class="form-group row">
            <label for="umur" class="col-sm-2 col-form-label">Umur</label>
            <div class="col-sm-10">
                <input type="number" class="form-control" name="umur" required="required" id="umur"
                    placeholder="Umur">
            </div>
        </div>

        <div class="form-group row">
            <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
            <div class="col-sm-10">
                <textarea name="alamat" required="required" id="alamat" placeholder="Alamat"></textarea>
            </div>
        </div>

        {{-- Nama <input type="text" name="nama" required="required"> <br/>
		Jabatan <input type="text" name="jabatan" required="required"> <br/>
		Umur <input type="number" name="umur" required="required"> <br/>
		Alamat <textarea name="alamat" required="required"></textarea> <br/> --}}
		<input type="submit" value="Simpan Data">
	</form>
@endsection
</body>
</html>
