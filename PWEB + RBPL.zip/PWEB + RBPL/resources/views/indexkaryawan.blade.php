@extends('kresna')

@section('atas')

@endsection

@section('isinya')


    <table class="table table-striped">
    <thead>
        <tr>
            <th>NIP</th>
            <th>Nama</th>
            <th>Pangkat</th>
            <th>Gaji</th>
            <th>Opsi</th>
        </tr>
    </thead>
        @foreach ($pegawai as $p)
        <tbody>
            <tr>
                <td>{{ $p->NIP }}</td>
                <td>{{ $p->Nama }}</td>
                <td>{{ $p->Pangkat }}</td>
                <td>{{ $p->Gaji }}</td>
                <td>
                    <a href="/pegawai/view/{{ $p->NIP }}" class="btn btn-primary" role="button">View</a>
                    <a href="/pegawai/edit/{{ $p->NIP }}" class="btn btn-primary" role="button">Edit</a>

                </td>
            </tr>
        </tbody>
        @endforeach
    </table>

@endsection

</body>

</html>
