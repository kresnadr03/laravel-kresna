@extends('kresna')

@section('atas')
<a href="/shoppingchart/beli" type="button" class="btn btn-primary"> Beli</a>
@endsection

@section('isinya')


    <table class="table table-striped">
    <thead>
        <tr>
            <th>Kode Barang</th>
            <th>Jumlah
                Pembelian
            </th>
            <th>Harga per
                Item
            </th>
            <th>Total
                Jumlah x Harga
            </th>
            <th>Opsi</th>
        </tr>
    </thead>
        @foreach ($pegawai as $p)
        <tbody>
            <tr>
                <td>{{ $p->id }}</td>
                <td>{{ $p->KodeBarang }}</td>
                <td>{{ $p->Jumlah }}</td>
                <td>{{ "Rp " . number_format($p->Harga,0,',','.') }}</td>
                <td>{{ "Rp " . number_format($p->Harga * $p->Jumlah,0,',','.') }}</td>
                <td>

                    <a href="/shoppingchart/batal/{{ $p->id }}" class="btn btn-primary" role="button">Batal</a>

                </td>
            </tr>
        </tbody>
        @endforeach
    </table>

@endsection

</body>

</html>
