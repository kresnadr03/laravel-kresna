@extends('kresna')

@section('atas')

@endsection

@section('isinya')
	<a href="/pegawai" type="button" class="btn btn-primary"> Kembali</a>

	<br/>
	<br/>

	@foreach($pegawai as $p)


        <div class="form-group row">
            <label for="nama" class="col-sm-2 col-form-label">Pegawai ID</label>
            <div class="col-sm-10">
                <label class="col-form-label">{{ $p->pegawai_id }}"</label>
            </div>
        </div>
        <div class="form-group row">
            <label for="nama" class="col-sm-2 col-form-label">Nama</label>
            <div class="col-sm-10">
                <label class="col-form-label">{{ $p->pegawai_nama }}"</label>
            </div>
        </div>

        <div class="form-group row">
            <label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-10">
                <label class="col-form-label">{{ $p->pegawai_jabatan }}"</label>
            </div>
        </div>

        <div class="form-group row">
            <label for="umur" class="col-sm-2 col-form-label">Umur</label>
            <div class="col-sm-10">
                <label class="col-form-label">{{ $p->pegawai_umur }}"</label>
            </div>
        </div>

        <div class="form-group row">
            <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
            <div class="col-sm-10">
                <label class="col-form-label">{{ $p->pegawai_alamat }}</label>
            </div>
        </div>

        {{-- Nama <input type="text" required="required" name="nama" value="{{ $p->pegawai_nama }}"> <br/>
		Jabatan <input type="text" required="required" name="jabatan" value="{{ $p->pegawai_jabatan }}"> <br/>
		Umur <input type="number" required="required" name="umur" value="{{ $p->pegawai_umur }}"> <br/>
		Alamat <textarea required="required" name="alamat">{{ $p->pegawai_alamat }}</textarea> <br/> --}}


	@endforeach

@endsection
</body>
</html>
