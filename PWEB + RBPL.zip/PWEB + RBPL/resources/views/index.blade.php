@extends('kresna')

@section('atas')
<a href="/pegawai/tambah" type="button" class="btn btn-primary"> + Tambah Pegawai Baru</a>
@endsection

@section('isinya')
<p>Cari Data Pegawai :</p>
	<form action="/pegawai/cari" method="GET">
		<input type="text" class="form-control" name="cari" placeholder="Cari Pegawai .." value="{{ old('cari') }}">
		<input class="btn btn-primary btn-sm" type="submit" value="CARI">
	</form>


    <table class="table table-striped">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Jabatan</th>
            <th>Umur</th>
            <th>Alamat</th>
            <th>Opsi</th>
        </tr>
    </thead>
        @foreach ($pegawai as $p)
        <tbody>
            <tr>
                <td>{{ $p->pegawai_nama }}</td>
                <td>{{ $p->pegawai_jabatan }}</td>
                <td>{{ $p->pegawai_umur }}</td>
                <td>{{ $p->pegawai_alamat }}</td>
                <td>
                    <a href="/pegawai/view/{{ $p->pegawai_id }}" class="btn btn-primary" role="button">View</a>
                    <a href="/pegawai/edit/{{ $p->pegawai_id }}" class="btn btn-primary" role="button">Edit</a>
                    <a href="/pegawai/hapus/{{ $p->pegawai_id }}" class="btn btn-primary" role="button">Hapus</a>

                </td>
            </tr>
        </tbody>
        @endforeach
    </table>
    {{ $pegawai->links() }}
@endsection

</body>

</html>
